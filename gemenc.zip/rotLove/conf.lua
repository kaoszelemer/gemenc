function love.conf(t)
    t.window = nil -- setmode is in love.load
end
